//
//  myTest.m
//  TouchBarDemo
//
//  Created by Max K on 10/03/17.
//  Copyright © 2017 Pratik Thakare. All rights reserved.
//

#import "myTest.h"
static NSTouchBarItemIdentifier WindowControllerLabelIdentifier = @"com.TouchBarCatalog.windowController.label";
@interface myTest ()<NSTouchBarDelegate>

@end

@implementation myTest

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}
- (NSTouchBar *)makeTouchBar
{
    NSTouchBar *bar = [[NSTouchBar alloc] init];
    bar.delegate = self;
    
    // Set the default ordering of items.
    bar.defaultItemIdentifiers =
    @[WindowControllerLabelIdentifier, NSTouchBarItemIdentifierOtherItemsProxy];
    
    return bar;
}

- (nullable NSTouchBarItem *)touchBar:(NSTouchBar *)touchBar makeItemForIdentifier:(NSTouchBarItemIdentifier)identifier
{
    if ([identifier isEqualToString:WindowControllerLabelIdentifier])
    {
        NSButton *button=[NSButton buttonWithTitle:@" Click me" target:self action:@selector(Clickme)];
        
        NSCustomTouchBarItem *customItemForLabel =
        [[NSCustomTouchBarItem alloc] initWithIdentifier:WindowControllerLabelIdentifier];
        customItemForLabel.view = button;
        
        // We want this label to always be visible no matter how many items are in the NSTouchBar instance.
        customItemForLabel.visibilityPriority = NSTouchBarItemPriorityHigh;
        
        return customItemForLabel;
    }
    
    return nil;
}
-(void)Clickme
{
    NSLog(@"You Clicked Me");
}
@end

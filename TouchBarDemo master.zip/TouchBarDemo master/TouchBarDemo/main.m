//
//  main.m
//  TouchBarDemo
//
//  Created by Max K on 09/03/17.
//  Copyright © 2017 Pratik Thakare. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}

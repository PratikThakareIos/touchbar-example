//
//  myTest.h
//  TouchBarDemo
//
//  Created by Max K on 10/03/17.
//  Copyright © 2017 Pratik Thakare. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface myTest : NSViewController
@property (strong,nonatomic)NSTextField *Text;
@end

//
//  MywindowController.m
//  TouchBarDemo
//
//  Created by Max K on 09/03/17.
//  Copyright © 2017 Pratik Thakare. All rights reserved.
//

#import "MywindowController.h"

@interface MywindowController ()


@end

@implementation MywindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
     myTest *testview=[[myTest alloc]initWithNibName:@"myTest" bundle:[NSBundle mainBundle]];
    NSViewController *newDetailViewController = testview;
    self.contentViewController=newDetailViewController;
  
    
    // Here we want to bind or sync our own NSTouchBar instance with the detail view controller.
    //[self unbind:@"touchBar"];
    [self bind:@"touchBar" toObject:newDetailViewController withKeyPath:@"touchBar" options:nil];

}

@end

//
//  AppDelegate.h
//  TouchBarDemo
//
//  Created by Max K on 09/03/17.
//  Copyright © 2017 Pratik Thakare. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

